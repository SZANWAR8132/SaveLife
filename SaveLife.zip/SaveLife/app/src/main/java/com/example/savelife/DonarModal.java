package com.example.savelife;
public class DonarModal {

    // variables for our coursename,
    // description, tracks and duration, id.
    private String donarName;
    private String donarAddress;
    private String donarNumber;
    private String donarType;
    private String donarDonate;
    private int id;

    // creating getter and setter methods
    public String getdonarName() {
        return donarName;
    }

    public void setdonarName(String donarName) {
        this.donarName = donarName;
    }

    public String getdonarAddress() {
        return donarAddress;
    }

    public void getdonarAddress(String donarAddress) {
        this.donarAddress = donarAddress;
    }

    public String getdonarNumber() {
        return donarNumber;
    }

    public void setdonarNumber(String donarNumber) {
        this.donarNumber = donarNumber;
    }

    public String getdonarType() {
        return donarType;
    }

    public void setdonarType(String donarType) {
        this.donarType= donarType;
    }
    public String getdonarDonate() {
        return donarDonate;
    }

    public void setdonarDonate(String donarDonate) {
        this.donarDonate = donarDonate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // constructor
    public DonarModal(String donarName, String donarAddress, String donarNumber, String donarType, String donarDonate) {
        this.donarName = donarName;
        this.donarAddress = donarAddress;
        this.donarNumber = donarNumber;
        this.donarType = donarType;
        this.donarDonate =donarDonate;
    }
}

