package com.example.savelife;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ViewReciepantList extends AppCompatActivity {

    // creating variables for our array list,
    // dbhandler, adapter and recycler view.
    private ArrayList<ReciepantModal> courseModalArrayList;
    private DBHandler1 dbHandler1;
    private ReciepantRVAdapter courseRVAdapter;
    private RecyclerView coursesRV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_reciepant_list);

        // initializing our all variables.
        courseModalArrayList = new ArrayList<>();
        DBHandler1 dbHandler1 = new DBHandler1(ViewReciepantList.this);

        // getting our course array
        // list from db handler class.
        courseModalArrayList = dbHandler1.readCourses();

        // on below line passing our array lost to our adapter class.
        courseRVAdapter = new ReciepantRVAdapter(courseModalArrayList, ViewReciepantList.this);
        coursesRV = findViewById(R.id.idRVCourses);

        // setting layout manager for our recycler view.
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ViewReciepantList.this, RecyclerView.VERTICAL, false);
        coursesRV.setLayoutManager(linearLayoutManager);

        // setting our adapter to recycler view.
        coursesRV.setAdapter(courseRVAdapter);
    }
}
