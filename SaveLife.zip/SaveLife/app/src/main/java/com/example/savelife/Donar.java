package com.example.savelife;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Donar extends AppCompatActivity {

    // creating variables for our edittext, button and dbhandler
    private EditText donarNameEdt, donaraddressEdt, donarNumberEdt, donarTypeEdt, donarDonateEdt;
    private Button submitBtn, donarlistBtn, reciepantlistBtn;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donar);

        // initializing all our variables.
        donarNameEdt = findViewById(R.id.Name);
        donaraddressEdt = findViewById(R.id.address);
        donarNumberEdt = findViewById(R.id.number);
        donarTypeEdt = findViewById(R.id.type);
        donarDonateEdt = findViewById(R.id.donate);
        submitBtn = findViewById(R.id.submit);
        donarlistBtn = findViewById(R.id.donarlist);
        reciepantlistBtn = findViewById(R.id.reciepantlist);

        // creating a new dbhandler class
        // and passing our context to it.
        dbHandler = new DBHandler(Donar.this);

        // below line is to add on click listener for our add course button.
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // below line is to get data from all edit text fields.
                String Name = donarNameEdt.getText().toString();
                String Address = donaraddressEdt.getText().toString();
                String number = donarNumberEdt.getText().toString();
                String type = donarTypeEdt.getText().toString();
                String donate = donarDonateEdt.getText().toString();

                // validating if the text fields are empty or not.
                if (Name.isEmpty() && Address.isEmpty() && number.isEmpty() && type.isEmpty() && donate.isEmpty()) {
                    Toast.makeText(Donar.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                // on below line we are calling a method to add new
                // course to sqlite data and pass all our values to it.
                dbHandler.addDonarData(Name, Address, number,type, donate);

                // after adding the data we are displaying a toast message.
                Toast.makeText(Donar.this, "Donars Data has been added.", Toast.LENGTH_SHORT).show();
                donarNameEdt.setText("");
                donaraddressEdt.setText("");
                donarNumberEdt.setText("");
                donarTypeEdt.setText("");
                donarDonateEdt.setText("");
            }
        });

        donarlistBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // opening a new activity via a intent.
                Intent i = new Intent(Donar.this, ViewDonarList.class);
                startActivity(i);
            }
        });
        reciepantlistBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // opening a new activity via a intent.
                Intent i = new Intent(Donar.this, ViewReciepantList.class);
                startActivity(i);
            }
        });
    }
}

