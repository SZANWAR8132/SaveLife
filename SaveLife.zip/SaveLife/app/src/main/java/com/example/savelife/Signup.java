package com.example.savelife;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Signup extends AppCompatActivity {
    EditText fullname,email,username,password,password1;
    Button signup;
    TextView login;
    DBhelper DB;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String userpattern = "[A-Z._]";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        fullname = (EditText)findViewById(R.id.fullname);
        email = (EditText)findViewById(R.id.email);
        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);
        password1 = (EditText)findViewById(R.id.password2);
        signup = (Button)findViewById(R.id.Signup);
        DB = new DBhelper(this);

        login = (TextView) findViewById(R.id.LogIn);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String full = fullname.getText().toString();
                String emai = email.getText().toString();
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String repass = password1.getText().toString();
                if (full.equals("") || emai.equals("") || user.equals("") || pass.equals("") || repass.equals(""))
                    Toast.makeText(Signup.this, "please enter all fields", Toast.LENGTH_SHORT).show();

                else {
                    if (email.getText().toString().trim().matches(emailPattern)) {
                        if (pass.equals(repass)) {
                            Boolean checkuser = DB.checkusername(user);
                            {
                                if (checkuser == false) {
                                    Boolean insert = DB.insertData(full, emai, user, pass);
                                    if (insert == true) {
                                        Toast.makeText(Signup.this, "REGISTERED SUCCESSFULLY", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(getApplicationContext(), Login.class);
                                        startActivity(intent);
                                    } else {
                                        Toast.makeText(Signup.this, "REGISTERED FAILED", Toast.LENGTH_SHORT).show();
                                    }
                                } else {
                                    Toast.makeText(Signup.this, "user already exist", Toast.LENGTH_SHORT).show();
                                }

                            }
                        } else {
                            Toast.makeText(Signup.this, "password isnt matching", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Invalid email address", Toast.LENGTH_SHORT).show();
                    }


                }

            }

        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Login.class );
                startActivity(intent);
            }
        });
    }

}